function [x,y] = raycast2D(start,goal,dx)
% performs a 2D raycast from the start location (x,y) to the goal location
% (x,y) with a scalar grid discretization defined by dx.  Returns a vector
% of x and y values for the raycast operation.


% figure(2),clf
% plot([start(1) goal(1)],[start(2) goal(2)],'-k')
% 
% 
% keyboard

% m = (goal(2)-start(2))./(goal(1)-start(1));     % slope = dy/dx
% if abs(m) > 1 
%     m = (goal(1)-start(1))./(goal(2)-start(2));	% slope = dx/dy
% end
% 
% start = round(start/dx)*dx;

% interpolation setting (change to 1 for bresenham line method)
N = 5;

m = (goal(2)-start(2))./(goal(1)-start(1));     % slope = dy/dx
if abs(m) > 1
    % redefine the raycast to avoid singularity in dy/dx for dx -> 0
    m = (goal(1)-start(1))./(goal(2)-start(2));	% slope = dx/dy
    b = goal(1) - m*goal(2);
    y = round(goal(2)/dx)*dx+(-5:1/N:5)*dx;
    x = round((m*y+b)/dx)*dx;
else
    b = goal(2) - m*goal(1);
    x = round(goal(1)/dx)*dx+(-5:1/N:5)*dx;
    y = round((m*x+b)/dx)*dx;
end


% This adds more info to the raycast
y = round(y/dx)*dx;
x = round(x/dx)*dx;

p = unique([x; y]','rows')';

x = p(1,:);
y = p(2,:);



return